package com.example.projecttwo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "inventory.db";
    public static final int DB_VER = 3;  // bump if schema changes

    // users
    public static final String T_USERS    = "users";
    public static final String U_ID       = "_id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";
    public static final String U_IS_ADMIN = "is_admin"; // 0/1

    // items
    public static final String T_ITEMS          = "items";
    public static final String I_ID             = "_id";
    public static final String I_NAME           = "name";
    public static final String I_LOCATION       = "location";
    public static final String I_QTY            = "qty";
    public static final String I_IS_CONSUMABLE  = "is_consumable"; // 0/1
    public static final String I_THRESHOLD      = "threshold";
    public static final String I_MAC            = "mac";

    public DbHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VER); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                U_USERNAME + " TEXT UNIQUE NOT NULL, " +
                U_PASSWORD + " TEXT NOT NULL, " +
                U_IS_ADMIN + " INTEGER NOT NULL DEFAULT 0" +
                ")");

        db.execSQL("CREATE TABLE " + T_ITEMS + " (" +
                I_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                I_NAME + " TEXT NOT NULL, " +
                I_LOCATION + " TEXT, " +
                I_QTY + " INTEGER NOT NULL DEFAULT 0, " +
                I_IS_CONSUMABLE + " INTEGER NOT NULL DEFAULT 0, " +
                I_THRESHOLD + " INTEGER NOT NULL DEFAULT 0, " +
                I_MAC + " TEXT" +
                ")");

        // seed admin/admin
        db.execSQL("INSERT OR IGNORE INTO " + T_USERS + " (" +
                U_USERNAME + ", " + U_PASSWORD + ", " + U_IS_ADMIN + ") " +
                "VALUES ('admin', 'admin', 1)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        onCreate(db);
    }
}
