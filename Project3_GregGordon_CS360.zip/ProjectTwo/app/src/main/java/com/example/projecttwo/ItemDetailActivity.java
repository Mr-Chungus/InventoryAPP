package com.example.projecttwo;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ItemDetailActivity extends AppCompatActivity {
    private ItemRepo repo;
    private long itemId = -1;

    private TextView title;
    private EditText editName, editLocation, editQty, editThreshold, editMac;
    private CheckBox checkConsumable;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        repo = new ItemRepo(this);

        title          = findViewById(R.id.detailTitle);
        editName       = findViewById(R.id.editName);
        editLocation   = findViewById(R.id.editLocation);
        editQty        = findViewById(R.id.editQty);
        editThreshold  = findViewById(R.id.editThreshold);
        editMac        = findViewById(R.id.editMac);
        checkConsumable= findViewById(R.id.checkConsumable);

        Button btnSave   = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        itemId = getIntent().getLongExtra("item_id", -1);
        if (itemId == -1) { finish(); return; }

        loadItem(); // prefill inputs

        btnSave.setOnClickListener(v -> {
            String name = s(editName);
            String loc  = s(editLocation);
            int qty     = toInt(s(editQty));
            int thr     = toInt(s(editThreshold));
            String mac  = s(editMac);
            boolean cons= checkConsumable.isChecked();

            if (name.isEmpty()) { toast("Name is required"); return; }

            repo.updateItem(itemId, name, loc, qty, cons, thr, mac);

            // optional: fire SMS if consumable is low
            if (cons && qty <= thr) {
                SmsUtil.trySendLowInventory(this, name, qty);
            }

            setResult(RESULT_OK);
            finish();
        });

        btnCancel.setOnClickListener(v -> finish());
    }

    //Loads an item
    private void loadItem() {
        Cursor c = repo.readById(itemId);
        if (c != null && c.moveToFirst()) {
            title.setText("Item Details");

            editName.setText(c.getString(c.getColumnIndexOrThrow(DbHelper.I_NAME)));
            editLocation.setText(c.getString(c.getColumnIndexOrThrow(DbHelper.I_LOCATION)));
            editQty.setText(String.valueOf(c.getInt(c.getColumnIndexOrThrow(DbHelper.I_QTY))));
            editThreshold.setText(String.valueOf(c.getInt(c.getColumnIndexOrThrow(DbHelper.I_THRESHOLD))));
            int isCons = c.getInt(c.getColumnIndexOrThrow(DbHelper.I_IS_CONSUMABLE));
            checkConsumable.setChecked(isCons == 1);
            String mac = c.getString(c.getColumnIndexOrThrow(DbHelper.I_MAC));
            if (mac != null) editMac.setText(mac);

            c.close();
        } else {
            toast("Item not found"); finish();
        }
    }

    private String s(EditText e){ return e.getText()==null? "" : e.getText().toString().trim(); }
    private int toInt(String v){ try { return Integer.parseInt(v); } catch (Exception e){ return 0; } }
    private void toast(String m){ Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }
}
