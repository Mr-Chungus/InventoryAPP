package com.example.projecttwo;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF = "auth_session";
    private static final String KEY_USER = "username";

    private final SharedPreferences sp;

    public SessionManager(Context ctx) {
        sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void login(String username) {
        sp.edit().putString(KEY_USER, username).apply();
    }

    public void logout() {
        sp.edit().remove(KEY_USER).apply();
    }

    public boolean isLoggedIn() {
        return sp.contains(KEY_USER);
    }

    public String currentUser() {
        return sp.getString(KEY_USER, null);
    }
}
