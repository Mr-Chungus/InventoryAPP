package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private TextInputEditText username, password;
    private UserRepo userRepo;
    private SessionManager session;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);
        if (session.isLoggedIn()) {
            goInventory();
            return;
        }

        username = findViewById(R.id.login_username);
        password = findViewById(R.id.login_password);
        Button btnLogin  = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreateAccount);

        userRepo = new UserRepo(this);
        userRepo.createAdminIfMissing(); // ensure admin/admin exists

        btnLogin.setOnClickListener(v -> {
            String u = txt(username), p = txt(password);
            if (u.isEmpty() || p.isEmpty()) { toast("Enter username and password"); return; }
            if (userRepo.validateLogin(u, p)) {
                session.login(u);
                goInventory();
            } else if (userRepo.userExists(u)) {
                toast("Wrong password");
            } else {
                toast("No account found. Please create an account first.");
            }
        });

        btnCreate.setOnClickListener(v -> {
            String u = txt(username), p = txt(password);
            if (u.isEmpty() || p.isEmpty()) { toast("Enter username and password"); return; }
            if (u.equalsIgnoreCase("admin")) { toast("'admin' already exists."); return; }
            boolean ok = userRepo.createUser(u, p);
            if (ok) {
                toast("Account created");
                session.login(u);
                goInventory();
            } else {
                toast("Username already exists");
            }
        });
    }

    private String txt(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void goInventory() {
        Intent i = new Intent(this, InventoryActivity.class);
        // Clear back stack so back from Inventory won’t return to a stale login
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }
}
