package com.example.projecttwo;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.VH> {
    private Cursor cursor;

    public interface OnRowAction {
        void onClick(long id);
        void onDelete(long id);
    }

    private final OnRowAction actions;

    public InventoryAdapter(Cursor c, OnRowAction actions) {
        this.cursor = c;
        this.actions = actions;
    }

    public void swap(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_row, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        if (!cursor.moveToPosition(position)) return;

        long id = cursor.getLong(cursor.getColumnIndexOrThrow(DbHelper.I_ID));
        String name = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.I_NAME));
        String loc = cursor.getString(cursor.getColumnIndexOrThrow(DbHelper.I_LOCATION));
        int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.I_QTY));
        int isCons = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.I_IS_CONSUMABLE));
        int thr = cursor.getInt(cursor.getColumnIndexOrThrow(DbHelper.I_THRESHOLD));

        h.name.setText(name);
        h.location.setText(loc);
        h.qty.setText(String.valueOf(qty));
        h.status.setText((isCons == 1 && qty <= thr) ? "LOW" : "OK");

        h.itemView.setOnClickListener(v -> actions.onClick(id));
        h.deleteBtn.setOnClickListener(v -> actions.onDelete(id));
    }

    @Override
    public int getItemCount() {
        return cursor == null ? 0 : cursor.getCount();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, location, qty, status;
        ImageButton deleteBtn;

        VH(View v) {
            super(v);
            name = v.findViewById(R.id.rowItemName);
            location = v.findViewById(R.id.rowItemLocation);
            qty = v.findViewById(R.id.rowItemQty);
            status = v.findViewById(R.id.rowItemStatus);
            deleteBtn = v.findViewById(R.id.rowDeleteButton);
        }
    }
}
