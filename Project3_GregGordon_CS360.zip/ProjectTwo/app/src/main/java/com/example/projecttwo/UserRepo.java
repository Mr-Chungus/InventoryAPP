package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepo {
    private final DbHelper helper;
    public UserRepo(Context ctx) { helper = new DbHelper(ctx); }

    //Creates user
    public boolean createUser(String username, String password) {
        try {
            SQLiteDatabase db = helper.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(DbHelper.U_USERNAME, username.trim());
            cv.put(DbHelper.U_PASSWORD, password);
            cv.put(DbHelper.U_IS_ADMIN, 0);
            long id = db.insertOrThrow(DbHelper.T_USERS, null, cv);
            return id != -1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //Code added to change the user password
    public void updatePassword(String username, String newPassword) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.U_PASSWORD, newPassword);
        db.update(DbHelper.T_USERS, cv, DbHelper.U_USERNAME + "=?", new String[]{username});
    }

    //Validates user login
    public boolean validateLogin(String username, String password) {
        try {
            SQLiteDatabase db = helper.getReadableDatabase();
            Cursor c = db.query(DbHelper.T_USERS,
                    new String[]{DbHelper.U_ID},
                    DbHelper.U_USERNAME + "=? AND " + DbHelper.U_PASSWORD + "=?",
                    new String[]{username.trim(), password},
                    null, null, null);
            boolean ok = c.moveToFirst();
            c.close();
            return ok;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //Checks if the user exist
    public boolean userExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(DbHelper.T_USERS,
                new String[]{DbHelper.U_ID},
                DbHelper.U_USERNAME + "=?", new String[]{username.trim()},
                null, null, null);
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // safety net to ensure admin exists at runtime
    public boolean createAdminIfMissing() {
        SQLiteDatabase db = helper.getWritableDatabase();
        Cursor c = db.query(DbHelper.T_USERS,
                new String[]{DbHelper.U_ID},
                DbHelper.U_USERNAME + "=?", new String[]{"admin"},
                null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        if (exists) return true;

        ContentValues cv = new ContentValues();
        cv.put(DbHelper.U_USERNAME, "admin");
        cv.put(DbHelper.U_PASSWORD, "admin");
        cv.put(DbHelper.U_IS_ADMIN, 1);
        return db.insert(DbHelper.T_USERS, null, cv) != -1;
    }
}
