package com.example.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class SmsPermissionActivity extends AppCompatActivity {
    private TextView status;

    private final ActivityResultLauncher<String> requestPerm =
            //Informs the user what actions were taken
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) {
                    status.setText("SMS permission granted. Low-stock alerts will be sent.");
                } else {
                    status.setText("Permission denied. App continues without SMS alerts.");
                }
                goBackToMain();
            });

    //Enables SMS messages for low stock alerts
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_sms_permission);

        Button allow = findViewById(R.id.btnAllowSms);
        Button deny  = findViewById(R.id.btnDenySms);
        status = findViewById(R.id.smsStatus);

        allow.setOnClickListener(v -> {
            if (SmsUtil.hasSmsPermission(this)) {
                status.setText("Already granted.");
                goBackToMain();
            } else {
                requestPerm.launch(android.Manifest.permission.SEND_SMS);
            }
        });

        deny.setOnClickListener(v -> {
            status.setText("SMS disabled. App still works.");
            goBackToMain();
        });
    }


    //Takes the user back to the main page
    private void goBackToMain() {
        Intent i = new Intent(this, InventoryActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }
}
