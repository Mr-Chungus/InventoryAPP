package com.example.projecttwo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

public class SmsUtil {
    public static boolean hasSmsPermission(Context ctx) {
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    public static void trySendLowInventory(Context ctx, String itemName, int qty) {
        if (!hasSmsPermission(ctx)) {
            Toast.makeText(ctx, "SMS permission not granted. Skipping alert.", Toast.LENGTH_SHORT).show();
            return;
        }
        String phone = "5551234567"; // for demo; make configurable later
        String msg = "Low inventory: " + itemName + " (qty " + qty + ")";
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(ctx, "SMS sent: " + msg, Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(ctx, "Failed to send SMS.", Toast.LENGTH_SHORT).show();
        }
    }
}
