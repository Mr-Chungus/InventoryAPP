package com.example.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryActivity extends AppCompatActivity {
    private ItemRepo repo;
    private InventoryAdapter adapter;
    private SessionManager session;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_inventory);

        session = new SessionManager(this);
        if (!session.isLoggedIn()) {
            // If user somehow reached here without session, go back to login
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        repo = new ItemRepo(this);

        RecyclerView rv = findViewById(R.id.recyclerInventory);
        rv.setLayoutManager(new LinearLayoutManager(this));

        Cursor data = repo.readAll();
        adapter = new InventoryAdapter(data, new InventoryAdapter.OnRowAction() {
            @Override public void onClick(long id) {
                Intent i = new Intent(InventoryActivity.this, ItemDetailActivity.class);
                i.putExtra("item_id", id);
                startActivity(i);
            }
            @Override public void onDelete(long id) {
                repo.delete(id);
                adapter.swap(repo.readAll());
            }
        });
        rv.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fabAddItem);
        fab.setOnClickListener(v ->
                startActivity(new Intent(this, AddEditItemActivity.class)));
    }


    @Override protected void onResume() {
        super.onResume();
        if (adapter != null) adapter.swap(repo.readAll());
    }

    // Inflate the menu with Sign Out
    @Override public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    //Creates a menu to let the user change password, enable SMS, and sign out.
    @Override public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_sign_out) {
            session.logout();
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            return true;
        }
        else if(item.getItemId() == R.id.action_change_password) {
            startActivity(new Intent(this, ChangePasswordActivity.class));
            return true;
        }else if (id == R.id.action_sms_permission) {
            startActivity(new Intent(this, SmsPermissionActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
