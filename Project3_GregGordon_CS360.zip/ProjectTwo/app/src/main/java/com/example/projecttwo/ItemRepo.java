package com.example.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class ItemRepo {
    private final DbHelper helper;
    public ItemRepo(Context ctx) { helper = new DbHelper(ctx); }

    //Used to Create and item
    public long create(String name, String location, int qty,
                       boolean consumable, int threshold, String mac) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.I_NAME, name);
        cv.put(DbHelper.I_LOCATION, location);
        cv.put(DbHelper.I_QTY, qty);
        cv.put(DbHelper.I_IS_CONSUMABLE, consumable ? 1 : 0);
        cv.put(DbHelper.I_THRESHOLD, threshold);
        cv.put(DbHelper.I_MAC, mac);
        return db.insert(DbHelper.T_ITEMS, null, cv);
    }

    public Cursor readAll() {
        SQLiteDatabase db = helper.getReadableDatabase();
        return db.query(DbHelper.T_ITEMS, null, null, null, null, null,
                DbHelper.I_NAME + " ASC");
    }

    //Update item information
    public int updateItem(long id,
                          String name,
                          String location,
                          int qty,
                          boolean consumable,
                          int threshold,
                          String mac) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.I_NAME, name);
        cv.put(DbHelper.I_LOCATION, location);
        cv.put(DbHelper.I_QTY, qty);
        cv.put(DbHelper.I_IS_CONSUMABLE, consumable ? 1 : 0);
        cv.put(DbHelper.I_THRESHOLD, threshold);
        cv.put(DbHelper.I_MAC, mac);
        return db.update(DbHelper.T_ITEMS, cv, DbHelper.I_ID + "=?",
                new String[]{ String.valueOf(id) });
    }

    //Update Quantity
    public int updateQty(long id, int newQty) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.I_QTY, newQty);
        return db.update(DbHelper.T_ITEMS, cv, DbHelper.I_ID + "=?",
                new String[]{String.valueOf(id)});
    }
    public Cursor readById(long id) {
        SQLiteDatabase db = helper.getReadableDatabase();
        return db.query(DbHelper.T_ITEMS, null,
                DbHelper.I_ID + "=?",
                new String[]{ String.valueOf(id) },
                null, null, null);
    }


    //Delete item
    public int delete(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        return db.delete(DbHelper.T_ITEMS, DbHelper.I_ID + "=?",
                new String[]{String.valueOf(id)});
    }
}
