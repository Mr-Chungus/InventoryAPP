package com.example.projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {
    private UserRepo userRepo;
    private String currentUser;


    //This is so the end user can change password for an account that they are signed into
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        userRepo = new UserRepo(this);
        currentUser = getIntent().getStringExtra("username");

        EditText oldPass = findViewById(R.id.oldPassword);
        EditText newPass = findViewById(R.id.newPassword);
        Button save = findViewById(R.id.btnSaveChange);

        save.setOnClickListener(v -> {
            String oldP = oldPass.getText().toString().trim();
            String newP = newPass.getText().toString().trim();

            if (oldP.isEmpty() || newP.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (userRepo.validateLogin(currentUser, oldP)) {
                userRepo.updatePassword(currentUser, newP);
                Toast.makeText(this, "Password updated successfully.", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Old password incorrect.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
