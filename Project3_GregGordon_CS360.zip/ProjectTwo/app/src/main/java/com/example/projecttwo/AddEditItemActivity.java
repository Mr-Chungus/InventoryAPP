package com.example.projecttwo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import com.google.android.material.textfield.TextInputEditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditItemActivity extends AppCompatActivity {
    private ItemRepo repo;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_add_edit_item);

        repo = new ItemRepo(this);

        TextInputEditText name = findViewById(R.id.editItemName);
        TextInputEditText loc  = findViewById(R.id.editItemLocation);
        TextInputEditText qty  = findViewById(R.id.editItemQty);
        CheckBox consumable    = findViewById(R.id.checkConsumable);
        TextInputEditText thr  = findViewById(R.id.editThreshold);

        Button save = findViewById(R.id.btnSave);
        Button cancel = findViewById(R.id.btnCancel);

        save.setOnClickListener(v -> {
            String n = t(name), l = t(loc), m = "";
            int q = toInt(t(qty));
            int tVal = toInt(t(thr));
            boolean c = consumable.isChecked();

            repo.create(n, l, q, c, tVal, m);

            if (c && q <= tVal) {
                SmsUtil.trySendLowInventory(this, n, q);
            }
            finish();
        });

        cancel.setOnClickListener(v -> finish());
    }

    private String t(TextInputEditText e){ return e.getText()==null? "": e.getText().toString().trim(); }
    private int toInt(String s){ try { return Integer.parseInt(s); } catch (Exception e){ return 0; } }
}
